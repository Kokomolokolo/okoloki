from flask import Flask, render_template, jsonify

app = Flask(__name__, template_folder='templates')


@app.route("/")
def test_site():
    return render_template("test_site.html")

def get_connection():
    print("connected")
    try:
        connection = psycopg2.connect(
            dbname="data",   # Replace with your database name
            user="okoloki",
	        password="123",         # Replace with your username
            host="localhost",             # Replace with your host
            port="5432"                   # Replace with your port
        )
        connection.autocommit = True
        return connection
    except psycopg2.Error as e:
        print(f"Error connecting to database: {e}")
        return None

# create table
@app.route('/create_table', methods=['GET'])
def create_table():
    connection = get_connection()
    if connection is None:
        return "Database connection failed", 500
    try:
        cursor = connection.cursor()
        create_table_query = """
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        );
        """
        cursor.execute(create_table_query)
        connection.commit()
        return "Table 'users' created successfully!", 200
    except Exception as e:
        return f"Error: {e}", 500
    finally:
        cursor.close()
        connection.close()

# @app.route("/api/save")
# def

if __name__ == "__main__":
    app.run(debug=True, port=8000)
