from flask import Flask, jsonify, request, render_template, session, make_response, redirect, url_for
import psycopg2
from flask_cors import CORS
from flask_session import Session

app = Flask(__name__, template_folder='templates')

user = None


app.secret_key = 'allesokolokobeidir'

app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'None'

# Enable CORS with credentials support
CORS(app, supports_credentials=True, origins=["https://www.okoloki.com"])

def cookie_check(redirected_site):
    user_data = session.get('user')
    return render_template(redirected_site)
    if True:
        username = user_data.get('username')  # Retrieves the username from the session data.
        return render_template(redirected_site, username=username)
    return render_template("login.html"), None

def admin_check():
    user_data = session.get('user')
    print("DEBUG - session user:", user_data)
    if user_data and user_data.get('username') in ['lennart', 'timon']:
        return True
    return False

@app.context_processor
def inject_user():
    return dict(user=session.get('user'))

def get_connection():
    print("connected")
    try:
        connection = psycopg2.connect(
            dbname="data",   # Replace with your database name
            user="okoloki",
	        password="123",         # Replace with your username
            host="localhost",             # Replace with your host
            port="5432"                   # Replace with your port
        )
        connection.autocommit = True
        return connection
    except psycopg2.Error as e:
        print(f"Error connecting to database: {e}")
        return None

# default route
@app.route('/')
def index():
    return cookie_check('Homepage.html')

@app.route('/login_site')
def loginPage():
    return render_template('login.html')

@app.route('/Blackjack')
def Blackjack():
    return cookie_check('bjr.html')

@app.route('/Encrypter')
def Encrypter():
    return cookie_check('encrypt_web.html')

@app.route('/Pong')
def Pong():
    return cookie_check('pong.html')

@app.route('/Game')
def Game():
    return cookie_check('game.html')

@app.route('/Register')
def Register():
    return render_template('register.html')

@app.route('/Second')
def Second():
    return cookie_check('second_page.html')

@app.route('/test_feature')
def testSite():
    if admin_check():
	    return render_template('index.html')

# create table
@app.route('/create_table', methods=['GET'])
def create_table():
    connection = get_connection()
    if connection is None:
        return "Database connection failed", 500
    try:
        cursor = connection.cursor()
        create_table_query = """
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        );
        """
        cursor.execute(create_table_query)
        connection.commit()
        return "Table 'users' created successfully!", 200
    except Exception as e:
        return f"Error: {e}", 500
    finally:
        cursor.close()
        connection.close()

# post
@app.route('/post_data', methods=['POST'])
def insert_data():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    connection = get_connection()
    if connection is None:
        return "Database connection failed", 500
    try:
        cursor = connection.cursor()
        # Write your INSERT query here as a multi-line string.
        insert_query = """
        INSERT INTO users (username, password)
        VALUES (%s, %s)
        ON CONFLICT (username) DO NOTHING;
        """
        cursor.execute(insert_query, (username, password))
        connection.commit()

        if cursor.rowcount > 0:
            return f"Data inserted: {username}", 201
        #else:
        #    return "Error: Username already exists", 400
    except Exception as e:
        connection.rollback()
        return f"Error: {e}", 500
    finally:
        cursor.close()
        connection.close()

# Route to fetch all data
@app.route('/data', methods=['GET'])
def get_data():
    if True:#admin_check():
        connection = get_connection()
        if connection is None:
            return "Database connection failed", 500
        try:
            cursor = connection.cursor()
            select_query = "SELECT * FROM users;"
            cursor.execute(select_query)
            rows = cursor.fetchall()
            # Format the data as JSON
            result = [
                {"id": row[0], "username": row[1], "password": row[2]}
                for row in rows
            ]
            return jsonify(result), 200
        except Exception as e:
            return f"Error: {e}", 500
        finally:
            cursor.close()
            connection.close()
    else:
        return 'You tried but we knew', 404

@app.route('/delete_data', methods=['DELETE'])
def delete_data():
    data = request.json
    id = data.get("id")
    username = data.get("username")
    password = data.get("password")

    connection = get_connection()
    if connection is None:
        return "Database connection failed", 500
    try:
        cursor = connection.cursor()
        delete_query = """
        DELETE FROM users
        WHERE username = %s;;
        """
        cursor.execute(delete_query, (username,))
        connection.commit()
        # return f"Data deleted: {username}, {password}", 201
        return f"Data deleted", 201
    except Exception as e:
        return f"Error: {e}", 500
    finally:
        cursor.close()
        connection.close()

@app.route('/login', methods=['POST'])
def login_with_data():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    connection = get_connection()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor()
        select_query = "SELECT * FROM users WHERE username = %s AND password = %s"
        cursor.execute(select_query, (username, password))
        user_record = cursor.fetchone()

        print("DEBUG: User record found:", user_record)

        if user_record:
            username = data.get("username")  # Provide a default if not sent
            
            session['user'] = {'username': username}
            # Return JSON rather than a plain string
            return jsonify({"message": "User logged in!"}), 200
        else:
            return jsonify({"error": "Invalid username or password"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        connection.close()

@app.route('/logout')
def logout():
    # Remove the user data from the session
    session.pop('user', None)
    
    # Optionally clear all session data
    # session.clear()

    # Prepare a response confirming logout
    resp = make_response(redirect(url_for('loginPage')))
    
    # Delete the session cookie (default cookie name is "session")
    resp.delete_cookie('session')
    
    return resp

if __name__ == "__main__":
    app.run(debug=True, port=5000)
