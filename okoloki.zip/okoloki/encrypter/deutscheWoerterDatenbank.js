export const deutscheWoerter = [
    "der", "die", "und", "in", "zu", "den", "das", "nicht", "von", "sie",
    "ist", "des", "sich", "mit", "dem", "dass", "er", "es", "ein", "ich",
    "auf", "so", "eine", "auch", "als", "an", "nach", "wie", "im", "für",
    "man", "aber", "aus", "durch", "wenn", "nur", "war", "noch", "werden", "bei",
    "hat", "wir", "was", "wird", "sein", "einen", "welche", "sind", "oder", "zur",
    "um", "haben", "einer", "mir", "über", "ihn", "diese", "einem", "ihr", "uns",
    "da", "zum", "kann", "doch", "vor", "dieser", "mich", "ihm", "sehr", "alle",
    "bis", "hier", "vom", "habe", "nun", "am", "soll", "will", "machen",
    "mehr", "mein", "sollte", "sagte", "geworden", "konnte", "müssen", "dies", "lassen", "nein",
    "dieses", "ohne", "einmal", "wohl", "selbst", "ihre", "immer", "unsere", "seit", "bin", "du", "schlafen",
    "alles", "nichts", "etwas", "jemand", "niemand", "viele", "wenige", "andere", "beide", "jeder",
    "immer", "nie", "heute", "morgen", "gestern", "bald", "jetzt", "damit", "weil", "während", "obwohl",
    "daher", "darum", "deshalb", "sofort", "oft", "selten", "manchmal", "überall", "nirgendwo", "hier",
    "dort", "draußen", "drinnen", "oben", "unten", "weiter", "zurück", "früher", "später", "schon", "noch",
    "mehr", "weniger", "genau", "fast", "etwa", "ganz", "sehr", "zu", "vielleicht", "eigentlich", "wirklich",
    "klar", "natürlich", "genug", "sicher", "langsam", "schnell", "gut", "schlecht", "richtig", "falsch",
    "einfach", "schwer", "leicht", "schön", "hässlich", "hoch", "tief", "lang", "kurz", "nah", "weit",
    "vorn", "hinten", "links", "rechts", "ob", "aber", "und", "oder", "dann", "danach", "bevor", "sobald",
    "wieso", "woher", "wohin", "weshalb", "wie", "wer", "was", "welche", "warum", "wann", "wo",
    "hi", "hallo", "moin"
]

