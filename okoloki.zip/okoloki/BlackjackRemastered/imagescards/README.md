# playing-cards
A deck of 52 cards (242x340 png) for card game projects<br>
<br>
A slighltly modified (added eyes + changed clothing color to match suit color for face cards) version of the original Grafik-fighter's file presented as separate card files for ease of use. <br>
<br>
To open the whole deck files (card-deck-*.sketch) download SKETCH app from https://www.sketchapp.com/ (Mac only tool) <br>
<br>
The original Grafik-fighter's file available at: https://www.sketchappsources.com/free-source/3060-cards-deck-template-sketch-freebie-resource.html
