function redirectToPage(subdomain) {
    window.location.href = `${subdomain}`;
}

const buttons = document.querySelectorAll(".knoepfe input");
let size = 1.05;

buttons.forEach((button) => {
    button.addEventListener('mouseenter', () => {
        // Animate the specific button being hovered
        button.animate([
            { transform: 'scale(1)' },
            { transform: `scale(${size})` } // Corrected string interpolation
        ], {
            duration: 100,
            fill: 'forwards' // Ensures the button remains scaled after the animation
        });
        button.style.transform = `scale(${size})`; // Corrected string interpolation
    });

    button.addEventListener('mouseleave', () => {
        // Animate the specific button when hover ends
        button.animate([
            { transform: `scale(${size})` },
            { transform: 'scale(1)' }
        ], {
            duration: 100,
            fill: 'forwards'
        });
        button.style.transform = 'scale(1)'; // Reset the scaling
    });
});

// habs gefixt